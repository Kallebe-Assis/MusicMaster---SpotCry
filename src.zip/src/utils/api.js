import axios from "axios";

const API_URL = "https://sua-api-aqui.com"; // Substitua pela URL da sua API

export const login = async (email, password) => {
  const response = await axios.post(`${API_URL}/login`, { email, password });
  return response.data.token;
};

export const register = async (email, password) => {
  try {
    console.log("Enviando dados para o registro:", { email, password });
    const response = await axios.post(`${API_URL}/register`, { email, password });
    console.log("Resposta da API:", response.data);  // Veja o que a API está retornando
    return response.data;  // Retorna a resposta da API
  } catch (error) {
    console.error("Erro ao registrar:", error.response ? error.response.data : error.message);
    throw error;  // Lança o erro para ser tratado no componente
  }
};

export const fetchMusic = async (token) => {
  const response = await axios.get(`${API_URL}/musics`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
};

export const createMusic = async (music, token) => {
  const response = await axios.post(`${API_URL}/musics`, music, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
};

export const deleteMusic = async (id, token) => {
  await axios.delete(`${API_URL}/musics/${id}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
};
