import axios from "axios";
import { getToken } from "./auth"; // Função de obter o token
import { useNavigate } from "react-router-dom";


const API_URL = "https://mqjnto3qw2.execute-api.us-east-1.amazonaws.com/default";

export const login = async (email, password) => {
  const response = await axios.post(`${API_URL}/user/login`, { email, password });
  const token = getToken();
  return response.data.token;
};

export const register = async (email, password) => {
  try {
    const response = await axios.post(`${API_URL}/register`, { email, password });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const logout = (navigate) => {
  // Remove o token do localStorage
  localStorage.removeItem('authToken');
  // Redireciona para a página de login
  navigate('/login');
};



export const getSongs = async () => {
  try {
    const token = getToken();
    if (!token) {  // Verifica se o token não é válido
      throw new Error("Usuário não autenticado");
    }
    const response = await axios.get(`${API_URL}/song`, {
      headers: { Authorization: `${token}` },
    });
    return response.data;
  } catch (err) {
    throw new Error('Erro ao carregar as músicas');
  }
};

export const getPlaylists = async () => {
  try {
    const token = getToken();
    if (!token) { 
      throw new Error("Usuário não autenticado");
    }
    const response = await axios.get(`${API_URL}/playlist`, {
      headers: { Authorization: `${token}` },
    });
    console.log(response.data)
    return response.data;
  } catch (err) {
    throw new Error('Erro ao carregar as músicas');
  }
};

export const getPlaylistSongs = async (playlistId) => {
  try {
    const token = getToken();
    if (!token) {  
      throw new Error("Usuário não autenticado");
    }
    const response = await axios.get(`${API_URL}/playlist/${playlistId}/song`, {
      headers: { Authorization: `${token}` },
    });
    console.log(response.data)
    return response.data;
  } catch (err) {
    throw new Error('Erro ao carregar as músicas');
  }
};



export const addPlaylist = async (playlistDetails) => {
  console.log("teteeeee:", playlistDetails)
  const token = getToken();
  if (!token) {
    throw new Error("Usuário não autenticado");
  }


  try {
    const response = await axios.post(`${API_URL}/playlist`, playlistDetails, {
      headers: {
        Authorization: `${token}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error("Erro ao adicionar playlist:", error.response || error);
    throw new Error(
      error.response?.data?.message || "Erro ao adicionar playlist"
    );
  }
};


export const removeTrackFromPlaylist = async (playlistId, songId) => {
  try {
    const token = getToken();
    const response = await axios.delete(
      `${API_URL}/playlist/${playlistId}/song/${songId}`,
      {
        headers: {
          Authorization: `${token}`, // Inclui o token no cabeçalho
        },
      }
    );
    return response.data;
  } catch (error) {
    console.log(playlistId)
    console.log(songId)
    console.error('Erro ao remover música da playlist:', error);
    throw error;
  }
};




export const addSong = async (songDetails) => {
  const token = getToken();
  if (!token) {
    throw new Error("Usuário não autenticado");
  }


  try {
    const response = await axios.post(`${API_URL}/song`, songDetails, {
      headers: {
        Authorization: `${token}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error("Erro ao adicionar música:", error.response || error);
    throw new Error(
      error.response?.data?.message || "Erro ao adicionar música"
    );
  }
};



export const addTrackToPlaylist = async (playlistId, songId) => {
  const token = getToken();
  if (!token) {
    throw new Error("Usuário não autenticado");
  }

  try {
    const response = await axios.post(`${API_URL}/playlist/${playlistId}/song`, { songId }, {
      headers: {
        Authorization: `${token}`,
      },
    });
    return response.data; // Retorna a resposta da API
  } catch (error) {
    console.error('Erro ao adicionar música à playlist:', error);
    throw error; 
  }
};




export const deleteSong = async (id) => {
  const token = getToken()
  if (!token) throw new Error("Usuário não autenticado");

  try {
    const response = await axios.delete(`${API_URL}/song/${id}`, {
      headers: {
        Authorization: `${token}`,
      },
    });
    return response.data;
  } catch (error) {
    throw new Error("Erro ao deletar música");
  }
};




// Função para validar o token com a API
export const validateToken = async (token) => {
  try {
    const response = await axios.get(`${API_URL}/user/validate`, {
      headers: {
        Authorization: `${token}`, // Envia o token no cabeçalho da requisição
      },
    });
    return response.data.valid; 
  } catch (error) {
    console.error("Erro ao validar token:", error);
    return false;
  }
};