const { createToken } = require('./validacaoToken');  // Importa a função para criar o token

// Exemplo de uma rota de login (quando o usuário faz login com sucesso)
const login = (req, res) => {
  const { email, password } = req.body;

  // Aqui você verificaria o email e a senha no banco de dados
  const user = { id: 123 };  // Exemplo de usuário autenticado com sucesso

  // Criação do token
  const token = createToken(user.id);

  // Retorna o token para o frontend
  res.json({ token });
};

module.exports = { login };
