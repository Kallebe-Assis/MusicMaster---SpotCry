const jwt = require('jsonwebtoken');

// Chave secreta para assinatura do token (mantenha em segredo)
const SECRET_KEY = 'the life not is strawberry';  // Substitua com a sua chave secreta

// Função para criar o token JWT
const createToken = (userId) => {
  const token = jwt.sign({ userId }, SECRET_KEY, { expiresIn: '1h' });  // Expira em 1 hora
  return token;
};

// Função para validar o token JWT
const validateToken = (token) => {
  try {
    const decoded = jwt.verify(token, SECRET_KEY);
    return decoded;  // Retorna o payload do token
  } catch (error) {
    throw new Error('Token inválido ou expirado');
  }
};

module.exports = { createToken, validateToken };
