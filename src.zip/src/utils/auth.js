import { jwtDecode } from "jwt-decode";

export const getToken = () => {
    return localStorage.getItem("authToken");  
};

export const setToken = (token) => {
    localStorage.setItem("authToken", token);  // Armazena o token com a chave correta
};

export const removeToken = () => {
    localStorage.removeItem("token");  // Remove o token corretamente
};



export const isAuthenticated = () => {
    const token = localStorage.getItem('token');  // Obtém o token armazenado

    if (!token) {
        return null;  // Retorna null se o token não estiver presente
    }

    
    const payload = JSON.parse(atob(token.split('.')[1]));  // Decodificando o token JWT
    const expiry = payload.exp * 1000;  // Expiração do token

    if (expiry < Date.now()) {
        localStorage.removeItem('token');  // Remove o token se estiver expirado
        return null;
    }

    return token;  // Retorna o token se for válido
};


export const getUserID = () => {
    const token = getToken(); 
    const decoded = jwtDecode(token);
    const userID = decoded.id;
    console.log("UserID:", userID);
    return userID;
}
