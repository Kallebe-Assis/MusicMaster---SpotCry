// Armazena o token no localStorage
export const setAuthToken = (token) => {
    localStorage.setItem('authToken', token);
  };
  
  // Obtém o token armazenado
  export const getAuthToken = () => {
    return localStorage.getItem('authToken');
  };
  
  // Remove o token (usado para logout)
  export const removeAuthToken = () => {
    localStorage.removeItem('authToken');
  };
  
  // Verifica se o usuário está autenticado
  export const isAuthenticated = () => {
    const token = getAuthToken();
    return !!token; // Retorna true se o token existir
  };
  
  export const logout = () => {
    removeAuthToken();
    window.location.href = '/login';
  };
  
  const { validateToken } = require('./validacaoToken');  // Importa a função de validação do token

const authenticate = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];  // 'Bearer token'

  if (!token) {
    return res.status(403).json({ message: 'Token não fornecido' });
  }

  try {
    const decoded = validateToken(token);  // Valida o token
    req.userId = decoded.userId;  // Salva o userId no objeto req para uso posterior
    next();  // Se o token for válido, prossegue para o próximo middleware ou rota
  } catch (error) {
    return res.status(403).json({ message: error.message });  // Caso o token seja inválido
  }
};

module.exports = authenticate;
