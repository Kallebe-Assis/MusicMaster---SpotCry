import React, { useState, useEffect } from "react";
import {
    PageWrapper,
    LoginContainer,
    Title,
    Subtitle,
    Form,
    Input,
    Button,
    RegistrarTexto
} from "../components/styles/LoginPageStyles";
import { register } from "../utils/api";
import { Link } from 'react-router-dom';
import Loader from "../components/Loader";

const RegisterPage = ({ onRegister }) => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [message, setMessage] = useState("");
    const [error, setError] = useState("");
    const [ loading, setLoading ] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 3000);
  }, []);

    const handleSubmit = async (event) => {
        event.preventDefault();

        if (password !== confirmPassword) {
            setError("As senhas não coincidem");
            setMessage("");
            return;
        }

        try {
            const token = await register(email, password);
            console.log("Token recebido após registro:", token);  
            setMessage("Registro realizado com sucesso!");
            setError("");
          } catch (error) {
            console.error("Erro ao registrar:", error);  
            setError("Erro ao registrar. Tente novamente.");
            setMessage("");
          }
    };

    return (
        <>
        {loading ? (
          <Loader />
        ) : (
        <PageWrapper>
            <LoginContainer>
                <Title>Crie sua Conta</Title>
                <Subtitle>Preencha os campos abaixo para se registrar</Subtitle>
                <Form onSubmit={handleSubmit}>
                    <Input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                    <Input
                        type="password"
                        placeholder="Senha"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <Input
                        type="password"
                        placeholder="Confirmar Senha"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                    />
                    <Button type="submit">Registrar</Button>
                </Form>

                {error && <p style={{ color: "red" }}>{error}</p>}
                {message && <p style={{ color: "green" }}>{message}</p>}
                <Link to="/login">
                    <RegistrarTexto>
                        <p>Já possui uma conta? Entre aqui.</p>
                    </RegistrarTexto>
                </Link>
            </LoginContainer>
        </PageWrapper>
        )}
    </>
    );
};

export default RegisterPage;
