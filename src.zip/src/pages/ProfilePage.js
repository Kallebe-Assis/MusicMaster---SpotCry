import React, { useState, useEffect } from "react";
import { ProfileWrapper, ProfileHeader, ProfilePicture, PlaylistsContainer, PlaylistCard, FavoriteTracksContainer, TrackCard, Title, Subtitle, FooterContainer, FooterContent, FooterLinks, HeaderWrapper, HeaderNav, BotaoBiblioteca, BarraInvisivel } from "../components/styles/ProfilePageStyles";
import logo from "./../assets/imgs/logo2.png";
import { LogoStyled } from "../components/styles/BibliotecaStyles";
import ProfileIcon from "../components/ProfileIcon";
import Loader from "../components/Loader";


const ProfilePage = () => {

  const [ loading, setLoading ] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 3000);
  }, []);

  const [profile, setProfile] = useState({
    nome: "Usuário",
    email: "usuario@email.com",
    fotoPerfil: "https://via.placeholder.com/150",
    playlists: [],
    favoriteTracks: [],
  });

  useEffect(() => {
    const mockData = {
      nome: "Usuário",
      email: "usuário@example.com",
      fotoPerfil: "https://via.placeholder.com/150", 
      playlists: [
        { id: 1, nome: "Favoritas", capa: "https://via.placeholder.com/100" },
        { id: 2, nome: "Relax", capa: "https://via.placeholder.com/100" },
        { id: 3, nome: "Workout", capa: "https://via.placeholder.com/100" },
      ],
      favoriteTracks: [
        { id: 1, titulo: "Song 1", artista: "Artista 1" },
        { id: 2, titulo: "Song 2", artista: "Artista 2" },
        { id: 3, titulo: "Song 3", artista: "Artista 3" },
      ],
    };
    setProfile(mockData);
  }, []);

  return (
    <>
    {loading ? (
      <Loader />
    ) : (
    <ProfileWrapper>
      <HeaderWrapper>
      <LogoStyled src={logo} ></LogoStyled>
        <HeaderNav>
          <ProfileIcon />
          <BotaoBiblioteca to="/biblioteca">Minha Biblioteca</BotaoBiblioteca>
        </HeaderNav>
      </HeaderWrapper>

      <ProfileHeader>
        <ProfilePicture src={profile.fotoPerfil} alt="Foto de perfil" />
        <div>
          <Title>{profile.nome}</Title>
          <Subtitle>{profile.email}</Subtitle>
        </div>
      </ProfileHeader>

      <h2>Playlists</h2>
      <PlaylistsContainer>
        {profile.playlists.map((playlist) => (
          <PlaylistCard key={playlist.id}>
            <img src={playlist.capa} alt="Foto de capa"></img>
            <p>{playlist.nome}</p>
          </PlaylistCard>
        ))}
      </PlaylistsContainer>

      <FavoriteTracksContainer>
        <h2>Músicas Favoritas</h2>
        {profile.favoriteTracks.map((track) => (
          <TrackCard key={track.id}>
            <p><strong>{track.titulo}</strong> - {track.artista}</p>
          </TrackCard>
        ))}
      </FavoriteTracksContainer>
      
      <BarraInvisivel />

      <FooterContainer>
        <FooterContent>
          <p>&copy; 2024 Spoticry. Todos os direitos reservados.</p>
          <FooterLinks>
            <a href="/sobre">Sobre</a>
            <a href="/contato">Contato</a>
            <a href="/privacidade">Política de Privacidade</a>
          </FooterLinks>
        </FooterContent>
      </FooterContainer>
    </ProfileWrapper>
    )}
    </>
  );
};

export default ProfilePage;
