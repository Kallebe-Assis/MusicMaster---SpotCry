import React, { useState, useEffect } from "react";
import logo from "./../assets/imgs/logo.png"
import { 
    PageBase,
    Header,
    Main,
    LogoStyled,
    TextoStyled,
    TextoPrincipalStyled,
    Highlight,
    LoginButton,
    RegisterButton
  } from "../components/styles/HomePageStyles";
  import GlobalStyle from "../components/styles/GlobalStyles";
  import { Link } from 'react-router-dom';
  import Loader from "../components/Loader";

const HomePage = () => {

    const [ loading, setLoading ] = useState(true);

    useEffect(() => {
      setTimeout(() => {
        setLoading(false);
      }, 3000);
    }, []);

    return (
        <>
        {loading ? (
          <Loader />
        ) : (
        <PageBase>
            <GlobalStyle />
            <Header>
                <LogoStyled src={logo}></LogoStyled>
                <div>
                    <Link to="/register">
                    <RegisterButton>Register</RegisterButton>
                    </Link>
                    <Link to="/login">
                    <LoginButton >Login</LoginButton>
                    </Link>
                </div>
            </Header>
            <Main>
                <TextoPrincipalStyled>MUSI<Highlight>CRY</Highlight></TextoPrincipalStyled>
                <TextoStyled>SINTA A <Highlight>MÚSICA</Highlight>, VIVA A <Highlight>EMOÇÃO</Highlight>.</TextoStyled><br /><br />
                <Link to="/register"><RegisterButton>COMEÇAR A OUVIR</RegisterButton></Link>
            </Main>
        </PageBase>
         )}
         </>
    )
}

export default HomePage;