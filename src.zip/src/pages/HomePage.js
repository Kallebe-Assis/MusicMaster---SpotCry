import React from "react";
import { Link } from 'react-router-dom';
import GlobalStyle from "../components/styles/GlobalStyles";
import { logout } from "../utils/auth";
import {
    Header,
    Highlight,
    LoginButton,
    LogoStyled,
    Main,
    PageBase,
    RegisterButton,
    TextoPrincipalStyled,
    TextoStyled
} from "../components/styles/HomePageStyles";
import logo from "./../assets/imgs/logo.png";

const HomePage = () => {
    return (
        <PageBase>
            <GlobalStyle />
            <Header>
                <LogoStyled src={logo}></LogoStyled>
                <div>
                    <Link to="/register">
                    <RegisterButton>Register</RegisterButton>
                    </Link>
                    <Link to="/login">
                    <LoginButton >Login</LoginButton>
                    </Link>
                </div>
            </Header>
            <Main>
                <TextoPrincipalStyled>MUSI<Highlight>CRY</Highlight></TextoPrincipalStyled>
                <TextoStyled>SINTA A <Highlight>MÚSICA</Highlight>, VIVA A <Highlight>EMOÇÃO</Highlight>.</TextoStyled><br /><br />
                <Link to="/register"><RegisterButton>COMEÇAR A OUVIR</RegisterButton></Link>
                <button onClick={logout}>Sair</button>
            </Main>
        </PageBase>
    )
}

export default HomePage;