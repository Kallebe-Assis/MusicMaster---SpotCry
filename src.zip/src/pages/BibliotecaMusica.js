import React, { useState } from "react";
import { useEffect } from 'react';
import logo from "./../assets/imgs/logo2.png"
import jwt_decode from "jwt-decode";
import musicaFoto from "./../assets/imgs/musicaFoto.jpg"
import {
  PageBase,
  Header,
  Main,
  LogoStyled,
  CardContainer,
  CardMusica,
  Botao,
  BotaoContainer,
  MusicaFoto,
  InfoMusicaNome,
  InfoMusicaArtista,
  InfoMusica,
  LogoutButton,
  Modal,
  ModalContent,
  CloseButton,
  DeleteButton,
  AddSongForm,
  SearchContainer,
  SearchInput,
  NoResultsMessage,
  DeleteFromPlaylistButton


} from "../components/styles/BibliotecaStyles";
import GlobalStyle from "../components/styles/GlobalStyles";
import { Link } from 'react-router-dom';
import { getUserID, isAuthenticated, userID } from "../utils/auth";
import ProfileIcon from "../components/ProfileIcon";
import { useNavigate } from 'react-router-dom'
import { useProtectedPage } from "../components/ProtectedPage";
import { logout, getSongs, deleteSong, addSong, getPlaylists, addPlaylist, getPlaylistSongs, addTrackToPlaylist, removeTrackFromPlaylist } from '../utils/api';
import Loader from "../components/Loader";

const Biblioteca = () => {
  const userID = getUserID()
  const navigate = useNavigate();
  const [musicas, setMusicas] = useState([]);
  const [playlists, setPlaylists] = useState([])
  const [playlistMusicas, setPlaylistMusicas] = useState([]);
  const [filteredPlaylists, setFilteredPlaylists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedMusic, setSelectedMusic] = useState(null);
  const [selectedPlaylist, setSelectedPlaylist] = useState(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isAddPlaylistModalOpen, setIsAddPlaylistModalOpen] = useState(false);
  const [newSong, setNewSong] = useState({ title: "", artist: "", url: "" });
  const [newPlaylist, setNewPlaylist] = useState({ name: "", description: "", userId: userID, songs: [] });
  const [filteredMusicas, setFilteredMusicas] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showPlaylists, setShowPlaylists] = useState(false);
  const [loadingPlaylistSongs, setLoadingPlaylistSongs] = useState(false);
  const [playlistError, setPlaylistError] = useState(null);
  const [playlistSearchQuery, setPlaylistSearchQuery] = useState("");
  const [selectedPlaylistId, setSelectedPlaylistId] = useState(null);
  useProtectedPage()


  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 3000);
  }, []);


  const handleMusicasClick = () => {
    setShowPlaylists(false);
    setFilteredMusicas(musicas); 
  };



  const handlePlaylistsClick = () => {
    setShowPlaylists(true);
  };

  const handlePlaylistClick = async (playlist) => {
    setSelectedPlaylist(playlist);
    setLoadingPlaylistSongs(true); 
    setPlaylistError(null);

    try {
      const data = await getPlaylistSongs(playlist._id);
      console.log("Músicas na playlist:", data.songs);

      // Mapeia os IDs para objetos de música completos
      const fullSongs = data.songs.map((songId) => {
        return musicas.find((musica) => musica.id === songId) || { id: songId, title: "Desconhecido", artist: "Desconhecido" };
      });

      setPlaylistMusicas(fullSongs); // Atualiza com as músicas completas
    } catch (err) {
      setPlaylistError("Erro ao carregar as músicas da playlist.");
      console.error(err);
    } finally {
      setLoadingPlaylistSongs(false); // Esconde o estado de carregamento
    }
  };

  const handleOpenModal = (musica) => {
    setSelectedMusic(musica);
  };

  // Função para fechar o modal
  const handleCloseModal = () => {
    setSelectedMusic(null);
    setSelectedPlaylist(null);
  };


  const handleAddMusicToPlaylist = async () => {
    if (!selectedPlaylistId || !selectedMusic) return;

    try {
      await addTrackToPlaylist(selectedPlaylistId, selectedMusic.id);

      alert('Música adicionada à playlist com sucesso!');
      setSelectedPlaylistId(null); 
      setSelectedMusic(null); // Fecha o modal
    } catch (error) {
      alert('Erro ao adicionar música à playlist. Tente novamente.');
    }
  };

  const handleRemoveSongFromPlaylist = async (playlistId, songId) => {
    try {
      await removeTrackFromPlaylist(playlistId, songId);  // Chama a função da API
      alert('Música removida da playlist com sucesso!');

      setPlaylistMusicas(prevMusicas => prevMusicas.filter(musica => musica.id !== songId));
    } catch (error) {
      console.log('Erro ao remover música da playlist. Tente novamente.');
    }
  };








  useEffect(() => {
    const fetchMusicas = async () => {
      try {
        const response = await getSongs(); // Chama a API
        console.log(response); // Verifique o conteúdo da resposta
        if (response && Array.isArray(response.songs)) {
          setMusicas(response.songs);
          setFilteredMusicas(response.songs); // Inicialmente, exibe todas as músicas
        } else {
          console.error("A resposta não contém o array de músicas esperado");
        }
      } catch (err) {
        console.error("Erro ao carregar as músicas:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchMusicas();

    const fetchPlaylists = async () => {
      try {
        const response = await getPlaylists();
        console.log(response);
        if (response && Array.isArray(response.playlists)) {
          setPlaylists(response.playlists);
          setFilteredPlaylists(response.playlists);
        } else {
          console.error("A resposta não contém o array de playlists esperado")
        }
      } catch (err) {
        console.error("Erro ao carregar as Playlists:", err);
      } finally {
        setLoading(false);
      }

    }

    fetchPlaylists();
  }, []);


  useEffect(() => {
    
    if (Array.isArray(musicas)) {
      if (searchQuery === "") {
        setFilteredMusicas(musicas); // Se não houver pesquisa, exibe todas as músicas
      } else {
        const filtered = musicas.filter(musica =>
          musica.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          musica.artist.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredMusicas(filtered);
      }
    }
  }, [searchQuery, musicas]);


  useEffect(() => {
    if (Array.isArray(playlists)) {
      if (playlistSearchQuery === "") {
        setFilteredPlaylists(playlists); // Se não houver pesquisa, exibe todas as playlists
      } else {
        const filtered = playlists.filter((playlist) =>
          playlist._name.toLowerCase().includes(playlistSearchQuery.toLowerCase()) ||
          playlist._description.toLowerCase().includes(playlistSearchQuery.toLowerCase())
        );
        setFilteredPlaylists(filtered); // Atualiza as playlists filtradas
      }
    }
  }, [playlistSearchQuery, playlists]);


  if (error) {
    return <div>{error}</div>;
  }

  const handleOpenAddPlaylistModal = () => setIsAddPlaylistModalOpen(true);
  const handleCloseAddPlaylistModal = () => setIsAddPlaylistModalOpen(false);

  const handleAddPlaylist = async (event) => {
    event.preventDefault();
    try {
      await addPlaylist(newPlaylist); // Chama a função da API
  
      setNewPlaylist({ name: "", description: "", userId: userID, songs: [] });
      handleCloseAddPlaylistModal(); // Fecha o modal de adicionar Playlist
      console.log("newpleiliste:", newPlaylist)

      const updatedPlaylists = await getPlaylists();

      const playlists = updatedPlaylists.playlists || updatedPlaylists;

      setPlaylists(playlists);

      if (searchQuery === "") {
        setFilteredPlaylists(playlists); // Se não houver pesquisa, exibe todas as Playlists
      } else {
        const filtered = playlists.filter(playlist =>
          playlist.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          playlist.description.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredPlaylists(filtered); // Atualiza as Playlists filtradas
        console.log("newpleiliste:", newPlaylist)
      }

    } catch (error) {
      console.log("newpleiliste:", newPlaylist)
      console.log(error.message);
    }
  };

  const handleOpenAddModal = () => setIsAddModalOpen(true);

  const handleCloseAddModal = () => setIsAddModalOpen(false);

  const handleAddSong = async (event) => {
    event.preventDefault();
    try {
      await addSong(newSong); 

      setNewSong({ title: "", artist: "", url: "" });
      handleCloseAddModal(); // Fecha o modal de adicionar música

      // Atualiza a lista de músicas
      const updatedSongs = await getSongs();

      const songs = updatedSongs.songs || updatedSongs; 

      setMusicas(songs);

      if (searchQuery === "") {
        setFilteredMusicas(songs);
      } else {
        const filtered = songs.filter(musica =>
          musica.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          musica.artist.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredMusicas(filtered); // Atualiza as músicas filtradas
      }

    } catch (error) {
      console.log(error.message);
    }
  };

  const handleDeleteMusic = async (id) => {
    try {
      
      await deleteSong(id);

      
      setMusicas((prevMusicas) => prevMusicas.filter((musica) => musica.id !== id));

      // Fecha o modal após excluir
      setSelectedMusic(null);
    } catch (error) {
      console.error("Erro ao deletar música:", error);
    }
  };

  return (
    <>
    {loading ? (
      <Loader />
    ) : (
    <PageBase>
      <GlobalStyle />
      <Header>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <LogoStyled src={logo}></LogoStyled>
          <p style={{ color: "white", fontWeight: "Bolder" }}>Sua Biblioteca</p>
          <ProfileIcon />
        </div>
        <div>
          <LogoutButton onClick={() => logout(navigate)} style={{ color: "white", fontWeight: "Bolder" }}>Logout</LogoutButton>
        </div>
      </Header>
      <Main>
        <BotaoContainer>
          <Botao onClick={handleMusicasClick}> {/* Botão para músicas */}
            <p>Músicas</p>
          </Botao>
          <Botao onClick={handlePlaylistsClick}> {/* Botão para playlists */}
            <p>Playlists</p>
          </Botao>
        </BotaoContainer>

        {showPlaylists ? (

          <CardContainer>
            <Botao onClick={handleOpenAddPlaylistModal}>
              <p>Criar Playlist</p>
            </Botao>
            <SearchContainer>
              <SearchInput
                type="text"
                placeholder="Pesquisar por playlist"
                value={playlistSearchQuery}
                onChange={(e) => setPlaylistSearchQuery(e.target.value)}
              />
            </SearchContainer>
            {filteredPlaylists.length === 0 ? (
              <NoResultsMessage>Nenhuma playlist encontrada</NoResultsMessage>
            ) : (
              filteredPlaylists.map((playlist) => (
                <CardMusica key={playlist._id} onClick={() => handlePlaylistClick(playlist)}>
                  <MusicaFoto src={musicaFoto} alt="Foto da playlist" />
                  <InfoMusica>
                    <InfoMusicaNome>{playlist._name}</InfoMusicaNome>
                    <InfoMusicaArtista>{playlist._description}</InfoMusicaArtista>
                  </InfoMusica>
                </CardMusica>
              ))
            )}


          </CardContainer>

          //MUSICAS
        ) : (
          <CardContainer>
            <Botao onClick={handleOpenAddModal}>
              <p>Adicionar Música</p>
            </Botao>
            {/* Barra de pesquisa */}
            <SearchContainer>
              <SearchInput
                type="text"
                placeholder="Pesquisar por música ou artista"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </SearchContainer>

            {filteredMusicas.length === 0 ? (
              <NoResultsMessage>Nenhuma música encontrada</NoResultsMessage>
            ) : (

              filteredMusicas.map((musica) => (
                <CardMusica key={musica.id} onClick={() => handleOpenModal(musica)}>
                  <MusicaFoto src={musicaFoto}></MusicaFoto>
                  <InfoMusica>
                    <InfoMusicaNome>{musica.title}</InfoMusicaNome>
                    <InfoMusicaArtista>{musica.artist}</InfoMusicaArtista>
                  </InfoMusica>
                </CardMusica>
              ))
            )}

          </CardContainer>
        )}

        {/* MODAIS */}

        {selectedPlaylist && (
          <Modal>
            <ModalContent>
              <CloseButton onClick={handleCloseModal}>×</CloseButton>
              <h2>{selectedPlaylist._name}</h2>
              <p>{selectedPlaylist._description}</p>
              <h3>Músicas:</h3>
              {loadingPlaylistSongs ? (
                <p>Carregando músicas...</p>
              ) : playlistError ? (
                <p>{playlistError}</p>
              ) : playlistMusicas.length === 0 ? (
                <p>Esta playlist não contém músicas.</p>
              ) : (
                playlistMusicas.map((musica) => (
                  <div key={musica.id}>
                    <p
                      style={{ cursor: "pointer", color: "blue" }}
                      onClick={() => handleOpenModal(musica)}
                    >{musica.title} - {musica.artist}</p>
                    <DeleteFromPlaylistButton onClick={() => handleRemoveSongFromPlaylist(selectedPlaylist._id, musica.id)}>
                      Remover da Playlist
                    </DeleteFromPlaylistButton>
                  </div>
                ))
              )}
            </ModalContent>
          </Modal>
        )}

        {selectedMusic && (
          <Modal>
            <ModalContent>
              <CloseButton onClick={() => setSelectedMusic(null)}>×</CloseButton>
              <h2>{selectedMusic.title}</h2>
              {/* <p>ID: {selectedMusic.id}</p> */}
              <p>Artista: {selectedMusic.artist}</p>

              <h3>Adicionar à Playlist:</h3>
              <select
                value={selectedPlaylistId || ""}
                onChange={(e) => setSelectedPlaylistId(e.target.value)}
              >
                <option value="" disabled>
                  Selecione uma playlist
                </option>
                {playlists.map((playlist) => (
                  <option key={playlist._id} value={playlist._id}>
                    {playlist._name}
                  </option>
                ))}
              </select>
              <DeleteButton onClick={handleAddMusicToPlaylist}>
                Adicionar à Playlist
              </DeleteButton>
              <DeleteButton onClick={() => handleDeleteMusic(selectedMusic.id)}>
                Deletar Música
              </DeleteButton>
            </ModalContent>
          </Modal>
        )}


        {isAddModalOpen && (
          <Modal>
            <ModalContent>
              <CloseButton onClick={handleCloseAddModal}>×</CloseButton>
              <h2>Adicionar Nova Música</h2>
              <AddSongForm onSubmit={handleAddSong}>
                <label>
                  Título:
                  <input
                    type="text"
                    value={newSong.title}
                    onChange={(e) => setNewSong({ ...newSong, title: e.target.value })}
                    required
                  />
                </label>
                <label>
                  Artista:
                  <input
                    type="text"
                    value={newSong.artist}
                    onChange={(e) => setNewSong({ ...newSong, artist: e.target.value })}
                    required
                  />
                </label>
                <label>
                  URL:
                  <input
                    type="text"
                    value={newSong.url}
                    onChange={(e) => setNewSong({ ...newSong, url: e.target.value })}
                    required
                  />
                </label>
                <DeleteButton type="submit">Adicionar</DeleteButton>
              </AddSongForm>
            </ModalContent>
          </Modal>
        )}
        {isAddPlaylistModalOpen && (
          <Modal>
            <ModalContent>
              <CloseButton onClick={handleCloseAddPlaylistModal}>×</CloseButton>
              <h2>Adicionar Nova Playlist</h2>
              <AddSongForm onSubmit={handleAddPlaylist}>
                <label>
                  Nome:
                  <input
                    type="text"
                    value={newPlaylist.name}
                    onChange={(e) => setNewPlaylist({ ...newPlaylist, name: e.target.value })}
                    required
                  />
                </label>
                <label>
                  Descrição:
                  <input
                    type="text"
                    value={newPlaylist.description}
                    onChange={(e) => setNewPlaylist({ ...newPlaylist, description: e.target.value })}
                    required
                  />
                </label>
                <DeleteButton type="submit">Adicionar</DeleteButton>
              </AddSongForm>
            </ModalContent>
          </Modal>
        )}
      </Main>
    </PageBase>
     )}
    </>
  )
}

export default Biblioteca;