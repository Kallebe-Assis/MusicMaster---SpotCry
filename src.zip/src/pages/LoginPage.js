import React, { useState } from "react";
import { PageWrapper, LoginContainer, Title, Subtitle, Form, Input, Button, Message, RegistrarTexto } from "../components/styles/LoginPageStyles";
import { login } from "../utils/api"; // Função de login para autenticar o usuário
import { Link, useNavigate } from 'react-router-dom';
import Biblioteca from "./BibliotecaMusica";

const LoginPage = ({ onLogin }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();



    setLoading (true);
    try {
      const token = await login(email, password); 
      localStorage.setItem("authToken", token);
      onLogin(true); 
      navigate("/biblioteca");
      

      setMessage("Login realizado com sucesso!");
    } catch (error) {
      setMessage("Erro ao realizar login. Verifique suas credenciais.");
    } finally {
      setLoading (false);
    }
  };

  if (loading) {
    return   <div>Carregando</div>
  }


  return (
    <PageWrapper>
      <LoginContainer>
        <Title>Bem-vindo ao MusiCry</Title>
        <Subtitle>Faça login para acessar sua conta</Subtitle>
        <Form onSubmit={handleSubmit}>
          <Input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Input
            type="password"
            placeholder="Senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <Button type="submit">Entrar</Button>
        </Form>
        {message && <Message>{message}</Message>}
        <Link to="/register">
          <RegistrarTexto>
            <p>Ainda não possui uma conta? Crie aqui.</p>
          </RegistrarTexto>
        </Link>
      </LoginContainer>
    </PageWrapper>
  );
};

export default LoginPage;
