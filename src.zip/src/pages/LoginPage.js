import React, { useState } from "react";
import { setAuthToken } from '../utils/auth';
import { Link } from 'react-router-dom';
import {
  Button,
  Form,
  Input,
  LoginContainer,
  Message,
  PageWrapper,
  RegistrarTexto,
  Subtitle,
  Title
} from "../components/styles/LoginPageStyles";
import { login } from "../utils/api"; // Função de login para autenticar o usuário

const LoginPage = ({ onLogin }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();
  
    try {
      const token = await login(email, password);
      setAuthToken(token); // Salva o token usando a função do auth.js
      setMessage('Login realizado com sucesso!');
      window.location.href = '/'; // Redireciona para a página inicial
    } catch (error) {
      setMessage('Erro ao realizar login. Verifique suas credenciais.');
    }
  };

  return (
    <PageWrapper>
      <LoginContainer>
        <Title>Bem-vindo ao MusiCry</Title>
        <Subtitle>Faça login para acessar sua conta</Subtitle>
        <Form onSubmit={handleSubmit}>
          <Input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Input
            type="password"
            placeholder="Senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <Button type="submit">Entrar</Button>
        </Form>
        {message && <Message>{message}</Message>}
        <Link to="/register">
          <RegistrarTexto>
            <p>Ainda não possui uma conta? Crie aqui.</p>
          </RegistrarTexto>
        </Link>
      </LoginContainer>
    </PageWrapper>
  );
};

export default LoginPage;
