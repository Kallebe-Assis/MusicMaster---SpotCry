import React, { useState } from "react";
import { Modal, ModalContent, CloseButton, ActionButton } from "../components/styles/BibliotecaStyles";
import { deleteSong } from "../utils/api";

const MusicDetailsModal = ({ isOpen, onClose, song, onDelete }) => {
  const [deleting, setDeleting] = useState(false);

  const handleDelete = async () => {
    if (!song?.id) return;

    try {
      setDeleting(true);
      await deleteSong(song.id); 
      onDelete(song.id); 
      onClose(); 
    } catch (error) {
      console.error("Erro ao deletar música:", error);
    } finally {
      setDeleting(false);
    }
  };

  if (!isOpen || !song) return null;

  return (
    <Modal>
      <ModalContent>
        <CloseButton onClick={onClose}>&times;</CloseButton>
        <h2>{song.title}</h2>
        <p>Artista: {song.artist}</p>
        <p>Álbum: {song.album || "Não disponível"}</p>
        <ActionButton onClick={handleDelete} disabled={deleting}>
          {deleting ? "Excluindo..." : "Excluir Música"}
        </ActionButton>
      </ModalContent>
    </Modal>
  );
};

export default MusicDetailsModal;