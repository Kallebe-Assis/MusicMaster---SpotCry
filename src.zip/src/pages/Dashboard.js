import React, { useState, useEffect } from "react";
import MusicList from "../components/MusicList";
import MusicForm from "../components/MusicForm";
import { fetchMusic } from "../utils/api";

const Dashboard = ({ token }) => {
  const [musics, setMusics] = useState([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const loadMusic = async () => {
      try {
        const data = await fetchMusic(token);
        setMusics(data);
      } catch {
        setMessage("Erro ao carregar músicas. Verifique seu token.");
      }
    };
    loadMusic();
  }, [token]);

  return (
    <div className="dashboard">
      <h1>Bem-vindo ao Gerenciador de Músicas</h1>
      {message && <p>{message}</p>}
      <MusicForm token={token} setMessage={setMessage} setMusics={setMusics} />
      <MusicList musics={musics} token={token} setMusics={setMusics} setMessage={setMessage} />
    </div>
  );
};

export default Dashboard;
