import React from "react";
import { PerfilIconeContainer, ImagemPerfil } from "./styles/ProfileIconStyles";
import PerfilIcon from "../assets/imgs/PerfilIcon.png";

const ProfileIcon = () => {
  return (
    <PerfilIconeContainer to="/profile">
      <ImagemPerfil src={PerfilIcon} alt="Perfil" />
    </PerfilIconeContainer>
  );
};

export default ProfileIcon;
