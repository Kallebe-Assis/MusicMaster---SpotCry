import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

export const useProtectedPage = () => {
    const navigate = useNavigate()

    useEffect(() => {
        const token = window.localStorage.getItem('authToken')

        if (!token) {
            navigate('/login')
        }


    }, [navigate])

    return <div>
        Essa página só pode ser acessada por usuários logados
    </div>
}