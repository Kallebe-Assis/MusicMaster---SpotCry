import styled from 'styled-components'
import { createGlobalStyle } from "styled-components";

// BASE



export const PageBase = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100vh;
  background-color: #0a0a0a; /* Fundo preto */

`;

export const Header = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    background-color: #121212; /* Fundo preto */
    padding: 2vh 0;


`

export const Main = styled.div`
    height: auto;
    display: flex;
    flex-direction: column;
    padding: 1% 10%;
    justify-content: space-evenly;
    align-items: center;
    background-color: #121212;
    /* background: linear-gradient(
      rgba(0, 0, 0, 0.5),
      rgba(0, 0, 0, 0.5)
    ), 
    url('Background');
  background-size: cover; 
  background-position: center;  */
`

// IMAGENS

export const LogoStyled = styled.img`
    width: 150px;
    height: auto;
    `

// CARDS

export const CardContainer = styled.div`
    background-color: #121212;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: row;
    flex-wrap: wrap;
    width: 90vw;
    height: auto;
    padding: 10px 50px;
    border-radius: 10px;
    user-select: none;

`

export const CardMusica = styled.div`
    background-color: #0a0a0a;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    width: 30%;
    height: 100px;
    border-radius: 30px;
    margin: 10px;
    color: #f3f3f3;
    font-weight: bolder;
    padding: 10px;
    transition: .1s;
    
    &:hover{
        transform: scale(1.03);
    }
`

export const InfoMusica = styled.div`
    width: 80%;
    display: flex;
    flex-direction: column;

`

export const InfoMusicaNome = styled.div`
    color: white;
    padding-bottom: 3%;
    border-bottom: 0.5px solid white;
`

export const InfoMusicaArtista = styled.div`
    margin-top: 3%;
    font-size: 12px;
    color: #f4f4f4;
`

export const MusicaFoto = styled.img`
    object-fit: cover;
    height: 100%;
    border-radius: 20px;
    margin-right: 10px;
    
`

export const NoResultsMessage = styled.div`
  color: white;
  font-size: 16px;
  text-align: center;
  width: 100%;
  padding: 20px;
  background-color: #1a1a1a;
  border-radius: 10px;
  margin-top: 20px;
`;

// BOTÕES

export const BotaoContainer = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    width: 40%;
    height: auto;
    margin-bottom: 1%;
`

export const Botao = styled.div`
    background-color: #f8f8f8;
    padding: 15px 0px;
    margin: 0px 10px;
    font-weight: bolder;
    border-radius: 10px;
    width: 30%;
    cursor: pointer;
    transition: .1s;
    text-align: center;
    font-size: larger;


    &:hover{
        background-color: #fff;
        transform: scale(110%);
    }
    `

export const LogoutButton = styled.button`
    border: none;
    color: white;
    background-color: #004dff;
    width: 200px;
    padding: 20px 0;
    border-radius: 10px;
    font-weight: bolder;
    font-size: 100%;
    margin: 0 2vw;
    transition: .2s;
    cursor: pointer;
    
    &:hover{
        transform: scale(1.1);
    }
    
    `;

// MODAL

export const Modal = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
`;

export const ModalContent = styled.div`
  background: white;
  padding: 20px;
  border-radius: 10px;
  width: 90%;
  max-width: 400px;
  text-align: center;
  position: relative;

  h2 {
    margin: 0 0 10px;
  }

  p {
    margin: 5px 0;
  }
`;

export const CloseButton = styled.button`
  position: absolute;
  top: 10px;
  right: 10px;
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
`;

export const DeleteButton = styled.button`
  background: #004dff;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 10px 20px;
  cursor: pointer;
  font-size: 16px;
  margin: 5px;

  &:hover {
    background: #004df8;
  }
`;

export const DeleteFromPlaylistButton = styled.button`
  background: red;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 5px 10px;
  cursor: pointer;
  font-size: 16px;
`

// MODAL ADICIONAR MUSICA

export const AddSongForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 10px;
  color: black;

  label {
    font-weight: bold;
    color: white;
    color: black;
  }

  input {
    padding: 8px;
    border-radius: 5px;
    border: 1px solid #ccc;
    color: black;
  }
`;


// BARRA DE PESQUISA

export const SearchContainer = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
  margin-top: 20px;
`;

export const SearchInput = styled.input`
  width: 80%;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ddd;
  border-radius: 25px;
  background-color: #222;
  color: white;
  outline: none;
  transition: border 0.3s;

  &:focus {
    border-color: #f8f8f8;
  }

  ::placeholder {
    color: #ccc;
  }
`;