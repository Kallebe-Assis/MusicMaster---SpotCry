import styled from "styled-components";
import { Link } from "react-router-dom";

export const PerfilIconeContainer = styled(Link)`
  display: inline-block;
  text-decoration: none;
  margin-left: 130vh;
  margin-top: 10px;
`;

export const ImagemPerfil = styled.img`
  width: 60px;
  height: 60px;
  border-radius: 50%;
  cursor: pointer;
  transition: .2s;
  
  &:hover{
        transform: scale(1.1);
    }
    
`;
