import styled from "styled-components";

export const ListWrapper = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
  width: 100%;
`;

export const MusicItem = styled.li`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px;
  margin: 10px 0;
  background-color: #222;
  border-radius: 5px;
`;

export const MusicDetails = styled.div`
  color: #fff;
`;

export const DeleteButton = styled.button`
  padding: 5px 10px;
  background-color: #ff5c5c;
  border: none;
  color: #fff;
  border-radius: 5px;
  cursor: pointer;

  &:hover {
    background-color: #ff7878;
  }
`;

