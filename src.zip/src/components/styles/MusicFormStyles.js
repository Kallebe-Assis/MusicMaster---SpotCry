import styled from "styled-components";

export const FormWrapper = styled.form`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

export const Label = styled.label`
  margin: 10px 0 5px;
  color: #fff;
  font-size: 14px;
`;

export const Input = styled.input`
  width: 100%;
  margin-bottom: 15px;
  padding: 10px;
  border-radius: 5px;
  border: 1px solid #444;
  background-color: #333;
  color: #fff;

  &:focus {
    border-color: #1db954;
    outline: none;
  }
`;

export const Button = styled.button`
  width: 100%;
  padding: 10px;
  background-color: #1db954;
  border: none;
  color: #fff;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;

  &:hover {
    background-color: #1ed760;
  }
`;

