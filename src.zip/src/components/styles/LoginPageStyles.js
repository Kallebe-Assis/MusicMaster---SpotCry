import styled from "styled-components";

export const PageWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100vh;
  background-color: #000; /* Fundo preto */
`;

export const LoginContainer = styled.div`
  background-color: #222; /* Fundo levemente mais claro */
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
  text-align: center;
  width: 100%;
  max-width: 400px;
`;

export const Title = styled.h1`
  color: #fff;
  margin-bottom: 10px;
`;

export const Subtitle = styled.p`
  color: #ccc;
  margin-bottom: 20px;
`;

export const Form = styled.form`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const Input = styled.input`
  display: block;
  width: 90%;
  margin: 10px auto;
  padding: 10px;
  border-radius: 5px;
  border: 1px solid #444;
  background-color: #333;
  color: #fff;

  &:focus {
    border-color: #004dff; /* Verde do Spotify */
    outline: none;
  }
`;

export const Button = styled.button`
  width: 90%;
  margin-top: 20px;
  padding: 10px;
  background-color: #004dff; /* Verde do Spotify */
  border: none;
  color: #fff;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;

  &:hover {
    background-color: #0042dc;
  }
`;

export const Message = styled.p`
  margin-top: 15px;
  font-size: 14px;
  color: ${(props) => (props.error ? "#ff5c5c" : "#2365ff")}; /* Dinâmico */
`;

export const RegistrarTexto = styled.p`
  color: #2365ff;
  cursor: pointer;
  text-decoration: none;

  &:hover{
    color: #fff;
  }
`;
