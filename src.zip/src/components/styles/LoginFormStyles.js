import styled from "styled-components";

export const FormWrapper = styled.form`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
`;

export const Input = styled.input`
  width: 90%;
  margin: 10px auto;
  padding: 10px;
  border-radius: 5px;
  border: 1px solid #444;
  background-color: #333;
  color: #fff;

  &:focus {
    border-color: #1db954;
    outline: none;
  }
`;

export const Button = styled.button`
  width: 90%;
  margin-top: 20px;
  padding: 10px;
  background-color: #1db954;
  border: none;
  color: #fff;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;

  &:hover {
    background-color: #1ed760;
  }
`;

