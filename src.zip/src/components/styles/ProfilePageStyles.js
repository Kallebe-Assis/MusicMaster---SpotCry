import styled from "styled-components";
import { Link } from "react-router-dom";

export const ProfileWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  background-color: #121212;
  color: white;
  min-height: 100vh;
  font-family: 'Arial', sans-serif;
  overflow-x: hidden;
`;

export const ProfileHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
  margin-bottom: 30px;
  padding: 10px;
  border-bottom: 2px solid #333;
  width: 100%;
  max-width: 1000px;
  margin-top: 140px;
`;

export const ProfilePicture = styled.img`
  width: 150px;
  height: 150px;
  border-radius: 50%;
  border: 4px solid #004dff;
  object-fit: cover;
  transition: transform 0.3s ease-in-out;
  
  &:hover {
    transform: scale(1.1);
  }
`;

export const Title = styled.h1`
  margin: 0;
  font-size: 2rem;
  font-weight: 600;
  color: #fff;
  text-align: left;
  padding: 5px;
`;

export const Subtitle = styled.h3`
  color: #ccc;
  font-size: 1.1rem;
  margin-top: 5px;
`;

export const PlaylistsTitle = styled.h2`
  color: #fff;
  font-size: 1.5rem;
  font-weight: 500;
  margin-top: 30px;
  margin-bottom: 15px;
  text-align: center;
`;

export const PlaylistsContainer = styled.div`
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  justify-content: center;
  margin-top: 30px;
`;

export const PlaylistCard = styled.div`
  background-color: #282828;
  border-radius: 10px;
  padding: 15px;
  width: 200px;
  text-align: center;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s ease, box-shadow 0.3s ease;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
  }
`;

export const FavoriteTracksContainer = styled.div`
  margin-top: 20px;
  width: 100%;
  max-width: 600px;
  margin-bottom: 40px;
`;

export const TrackCard = styled.div`
  background-color: #282828;
  border-radius: 10px;
  padding: 10px;
  margin: 5px 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
`;

export const TrackTitle = styled.span`
  font-size: 1rem;
  color: #fff;
`;

export const Button = styled.button`
  background-color: #004dff;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 20px;
  cursor: pointer;
  font-size: 16px;
  margin-top: 20px;
  transition: background-color 0.3s, transform 0.2s;
  margin-bottom: 150px;

  &:hover {
    background-color: #004dff;
    transform: scale(1.05);
  }

  &:active {
    background-color: #004dff;
  }
`;

export const BarraInvisivel = styled.div`
  margin-bottom: 20vh;
`;

// Estilo para o Header
export const HeaderWrapper = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background-color: #121212;
  width: 98%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 10;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
`;


export const HeaderNav = styled.nav`
  display: flex;
  gap: 20px;
`;

export const NavLink = styled.a`
  color: #fff;
  font-size: 1rem;
  text-decoration: none;

  &:hover {
    text-decoration: underline;
  }
`;

// Estilo para o Footer
export const FooterContainer = styled.footer`
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #121212;
  color: white;
  padding: 20px;
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  z-index: 10;
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.3);
`;

export const FooterContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`;

export const FooterLinks = styled.div`
  margin-top: 10px;
`;

export const FooterLink = styled.a`
  color: white;
  text-decoration: none;
  margin: 0 15px;

  &:hover {
    text-decoration: underline;
  }
`;

// Estilo para o botão
export const BotaoBiblioteca = styled(Link)`
  display: inline-block;
  padding: 25px 20px;
  background-color: #004dff;
  color: white;
  font-size: 16px;
  text-align: center;
  border-radius: 35px;
  text-decoration: none;
  transition: background-color 0.3s ease;
  transition: .2s;
  cursor: pointer;
  margin-left: auto;

  &:hover {
    background-color: #003bb5; 
  }

  &:hover{
        transform: scale(1.1);
    }

`;



