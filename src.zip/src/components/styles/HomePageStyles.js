import styled from 'styled-components'
// import { createGlobalStyle } from "styled-components";

export const PageBase = styled.div`
  display: flex;
  flex-direction: column;
  width: 100vw;
  height: 100vh;
  background-color: #0a0a0a; /* Fundo preto */
`;

export const Header = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    background-color: #121212; /* Fundo preto */
    padding: 2vh 0;


`

export const Main = styled.div`
    display: flex;
    flex-direction: column;
    padding: 10vh 10%;
    /* background: linear-gradient(
      rgba(0, 0, 0, 0.5),
      rgba(0, 0, 0, 0.5)
    ), 
    url('Background');
  background-size: cover; 
  background-position: center;  */
`

// IMAGEMS

export const LogoStyled = styled.img`
    width: 250px;
    height: auto;
`

// TEXTOS

export const TextoPrincipalStyled = styled.h1`
    color: white;
    font-weight: bold;
    font-size: 100px;
`

export const TextoStyled = styled.h2`
    color: white;
    font-weight: bold;
    font-size: 50px;
`

export const Highlight = styled.span`
  color: #004dff;
`;

// BOTÕES

export const LoginButton = styled.button`
    border: none;
    color: white;
    background-color: #004dff;
    width: 200px;
    padding: 20px 0;
    border-radius: 10px;
    font-weight: bolder;
    font-size: 100%;
    margin: 0 2vw;
    transition: .2s;
    cursor: pointer;
    
    &:hover{
        transform: scale(1.1);
    }
    
    `;

export const RegisterButton = styled.button`
    border: none;
    color: #000;
    background-color: #fff;
    width: 200px;
    padding: 20px 0;
    border-radius: 10px;    
    font-weight: bolder;
    font-size: 100%;
    transition: .2s;
    cursor: pointer;
    
    &:hover{
        transform: scale(1.1);
    }

`;