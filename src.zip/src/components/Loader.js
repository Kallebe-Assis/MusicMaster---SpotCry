import React from "react";
import {LoaderContainer, LoaderCircle} from "./styles/LoaderStyles";

const Loader = () => (
    <LoaderContainer>
      <LoaderCircle />
    </LoaderContainer>
  );
  
export default Loader;