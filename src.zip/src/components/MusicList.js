import React from "react";
import {
  DeleteButton,
  ListWrapper,
  MusicDetails,
  MusicItem,
} from "./styles/MusicListStyles";

const MusicList = ({ musicList, onDelete }) => {
  return (
    <ListWrapper>
      {musicList.map((music) => (
        <MusicItem key={music.id}>
          <MusicDetails>
            <strong>{music.title}</strong> - {music.artist} ({music.genre})
          </MusicDetails>
          <DeleteButton onClick={() => onDelete(music.id)}>Excluir</DeleteButton>
        </MusicItem>
      ))}
    </ListWrapper>
  );
};

export default MusicList;
