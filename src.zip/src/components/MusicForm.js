import React from "react";
import { FormWrapper, Input, Button, Label } from "./styles/MusicFormStyles";

const MusicForm = ({ musicData, setMusicData, onSubmit }) => {
  const handleChange = (e) => {
    setMusicData({ ...musicData, [e.target.name]: e.target.value });
  };

  return (
    <FormWrapper onSubmit={onSubmit}>
      <Label>Nome da Música</Label>
      <Input
        name="title"
        type="text"
        placeholder="Título"
        value={musicData.title}
        onChange={handleChange}
        required
      />
      <Label>Artista</Label>
      <Input
        name="artist"
        type="text"
        placeholder="Artista"
        value={musicData.artist}
        onChange={handleChange}
        required
      />
      <Label>Gênero</Label>
      <Input
        name="genre"
        type="text"
        placeholder="Gênero"
        value={musicData.genre}
        onChange={handleChange}
      />
      <Button type="submit">Salvar Música</Button>
    </FormWrapper>
  );
};

export default MusicForm;
