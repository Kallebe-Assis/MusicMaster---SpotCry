import React from "react";
import { FormWrapper, Input, Button } from "./styles/LoginFormStyles";

const LoginForm = ({ email, setEmail, password, setPassword, onSubmit }) => {
  return (
    <FormWrapper onSubmit={onSubmit}>
      <Input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)} // Usa setEmail corretamente
        required
      />
      <Input
        type="password"
        placeholder="Senha"
        value={password}
        onChange={(e) => setPassword(e.target.value)} // Usa setPassword corretamente
        required
      />
      <Button type="submit">Entrar</Button>
    </FormWrapper>
  );
};

export default LoginForm;
