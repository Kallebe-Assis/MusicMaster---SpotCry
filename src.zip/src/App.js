import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"; // Alterado para 'Routes'
import LoginPage from "./pages/LoginPage";  // Importação da página de Login
import RegisterPage from "./pages/RegisterPage";  // Importação da página de Register
import HomePage from "./pages/HomePage";  // Importação da página inicial
import PrivateRoute from "./components/PrivateRoute";

// import HomePage from "./HomePage";    // Exemplo de outra página

function App() {
  return (
    <Router>
      <Routes>
        {/* <Route path="/" element={<HomePage />} /> */}
        <Route path="/login" element={<LoginPage />} />  {/* Página de login */}
        <Route path="/register" element={<RegisterPage />} />  {/* Página de registro */}
        <Route
          path="/"
          element={
            <PrivateRoute>
              <HomePage />
            </PrivateRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
