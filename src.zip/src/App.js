// App.js
import React, { useEffect, useState } from "react";
import { Route, BrowserRouter as Router, Routes } from "react-router-dom"; 
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import ProfilePage from "./pages/ProfilePage";
import { isAuthenticated } from './utils/auth';
import Biblioteca from "./pages/BibliotecaMusica";
import { useProtectedPage } from "./components/ProtectedPage";


function App() {
  const [authToken, setAuthToken] = useState(null);

  useEffect(() => {
    const token = isAuthenticated();
    setAuthToken(token);  // Armazena o token ou null
  }, []);


  return (
    <Router>
      <Routes>
        <Route 
          path="/" 
          element={<HomePage />}  // Redireciona se não autenticado
        />
        <Route 
          path="/login" 
          element={<LoginPage onLogin={setAuthToken} />}  
        />
        <Route 
          path="/register" 
          element={<RegisterPage />} 
        />
        <Route 
          path="/biblioteca" 
          element={<Biblioteca />
          }
        />
         <Route
          path="/profile"
          element={
            <ProfilePage />
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
